# Como a cena 09 foi feita

## Objetivo

A cena compara tres tipos de colisao: elastica, inelastica e perfeitamente inelastica. O espectador acompanha primeiro pequenas demonstracoes visuais em tres paineis; depois surge uma tabela com momento linear, energia cinetica, comportamento apos o impacto e coeficiente de restituicao.

## Conceitos de fisica

Para um sistema isolado, o momento linear total se conserva em todos os tres casos: `p_total,antes = p_total,depois`. A energia cinetica, por sua vez, se conserva somente na colisao elastica ideal. Na inelastica, uma parte se converte em outras formas de energia. Na perfeitamente inelastica, os corpos ficam unidos apos o impacto.

| Tipo | Momento linear | Energia cinetica | Apos o impacto | Coeficiente e |
| --- | --- | --- | --- | --- |
| Elastica | Conservado | Conservada | Corpos se separam | `e = 1` |
| Inelastica | Conservado | Nao conservada | Podem se separar | `0 < e < 1` |
| Perfeitamente inelastica | Conservado | Nao conservada | Corpos unidos | `e = 0` |

O coeficiente de restituicao descreve a velocidade relativa de separacao comparada a velocidade relativa de aproximacao, na direcao da colisao. As trajetorias e distancias das bolinhas nesta cena sao **esquematicas**, usadas para ilustrar as categorias; nao representam uma simulacao numerica calibrada de um experimento.

## Construcao no Remotion

`src/Root.tsx` registra uma unica composicao de `750` quadros, `30` fps e `1280 x 720` pixels. A prop `dark: true` seleciona o fundo quase preto e cores claras. `src/Scene09.tsx` usa `useCurrentFrame()` para obter o quadro atual. A funcao `ease()` transforma intervalos de quadros em valores suaves de 0 a 1 por meio de `interpolate`.

Cada painel usa `CollisionPanel` para posicionar e mover duas bolinhas. `PanelBall` constroi as bolinhas como SVG: gradiente radial, contorno e marcas curvas. As marcas recebem uma rotacao calculada a partir do deslocamento horizontal, criando sensacao de rolamento. `PanelImpact` emite pequenos raios amarelos no ponto de contato; a sua opacidade cresce e desaparece em um intervalo curto. Os paineis mudam de foco conforme cada tipo de colisao e apresentado.

Depois das demonstracoes, `insights` revela as caracteristicas de cada tipo. `panelRows` gera a tabela comparativa. Por ultimo, aparece `p_total = constante`. Os elementos nao usam `setTimeout`, fotos ou video pre-gravado: tudo e redesenhado deterministicamente a partir do numero do quadro.

## Linha do tempo

| Quadro aproximado | Tempo aproximado | Evento |
| --- | --- | --- |
| 0-32 | 0-1,1 s | Titulo e subtitulo entram. |
| 54-172 | 1,8-5,7 s | Colisao elastica no primeiro painel. |
| 115-248 | 3,8-8,3 s | Destaque do momento, energia e restituicao elastica. |
| 196-314 | 6,5-10,5 s | Colisao inelastica no segundo painel. |
| 248-390 | 8,3-13,0 s | Destaque da colisao inelastica. |
| 338-456 | 11,3-15,2 s | Colisao perfeitamente inelastica no terceiro painel. |
| 390-510 | 13,0-17,0 s | Destaque dos corpos unidos e `e = 0`. |
| 485-645 | 16,2-21,5 s | Quadro comparativo aparece linha a linha. |
| 656-688 | 21,9-22,9 s | Conclusao `p_total = constante` aparece. |
| 749 | 25 s | Ultimo quadro da composicao. |

Os intervalos se sobrepoem de proposito. Assim, a informacao nova entra enquanto o movimento anterior termina, mantendo a cena continua e legivel.
