# Cena 09 - quadro de sintese comparativo

Projeto Remotion independente que reproduz **somente a versao da cena 09 com tres paineis e fundo preto**. A referencia e `Cena09-v02-tres-paineis-fundo-preto.mp4`. Nao inclui a cena do exemplo numerico, a versao clara nem o quadro inicial. As bolinhas e todos os outros elementos visuais sao gerados com React e SVG; nao ha fotos, videos externos ou audio.

## Abrir e reproduzir

Requisitos: Node.js e npm. No terminal, dentro desta pasta:

```sh
npm ci
npm run dev
```

O Remotion Studio abre em `http://localhost:3004`. Escolha a composicao `Cena09TresPaineisEscuro` para percorrer os quadros.

Para conferir o codigo e gerar o MP4:

```sh
npm run lint
npm run render
```

O arquivo sai em `out/Cena09TresPaineisEscuro.mp4`. Se ele ja existir, o script cria `-v02`, `-v03` etc. e preserva os renders antigos. `node_modules/` e `out/` nao entram no GitHub.

## Estrutura

| Arquivo | Funcao |
| --- | --- |
| `src/index.ts` | Registra a raiz no Remotion. |
| `src/Root.tsx` | Define composicao, fundo preto, 1280 x 720, 30 fps e 750 quadros. |
| `src/Scene09.tsx` | Desenha e anima os tres paineis, bolinhas, impactos, textos e tabela final. |
| `scripts/render.cjs` | Exporta H.264 com nome versionado. |
| `COMO_FOI_FEITO.md` | Explica a fisica, os elementos e a linha do tempo. |

Duracao: `750 / 30 = 25` segundos. O codigo usa apenas `react` e `remotion`; as dependencias exatas estao fixadas no `package-lock.json`.
