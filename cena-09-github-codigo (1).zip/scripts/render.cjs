const fs = require("node:fs");
const path = require("node:path");
const {bundle} = require("@remotion/bundler");
const {getCompositions, renderMedia} = require("@remotion/renderer");

const root = path.resolve(__dirname, "..");
const outputDir = path.join(root, "out");
fs.mkdirSync(outputDir, {recursive: true});

let output;
for (let version = 1; !output; version++) {
  const suffix = version === 1 ? "" : `-v${String(version).padStart(2, "0")}`;
  const candidate = path.join(outputDir, `Cena09TresPaineisEscuro${suffix}.mp4`);
  if (!fs.existsSync(candidate)) output = candidate;
}

async function main() {
  const serveUrl = await bundle({
    entryPoint: path.join(root, "src", "index.ts"),
    rootDir: root,
    rspack: true,
  });
  const compositions = await getCompositions(serveUrl);
  const composition = compositions.find((item) => item.id === "Cena09TresPaineisEscuro");
  if (!composition) throw new Error("Composicao Cena09TresPaineisEscuro nao encontrada");

  await renderMedia({
    serveUrl,
    composition,
    codec: "h264",
    outputLocation: output,
    overwrite: false,
    concurrency: 2,
  });
  console.log(`Video salvo em ${output}`);
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
