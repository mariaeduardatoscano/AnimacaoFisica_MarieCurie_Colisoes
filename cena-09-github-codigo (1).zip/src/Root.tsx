import React from "react";
import {Composition} from "remotion";
import {ThreePanelSummaryScene} from "./Scene09";

export const Root: React.FC = () => (
  <Composition
    id="Cena09TresPaineisEscuro"
    component={ThreePanelSummaryScene}
    defaultProps={{dark: true}}
    durationInFrames={750}
    fps={30}
    width={1280}
    height={720}
  />
);
