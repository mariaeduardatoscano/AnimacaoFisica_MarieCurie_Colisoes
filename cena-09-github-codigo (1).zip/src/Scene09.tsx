import React from "react";
import {AbsoluteFill, interpolate, useCurrentFrame} from "remotion";

const paper = "#f3f4f1";
const ink = "#202723";
const muted = "#68736b";
const rule = "#bec5bf";
const red = "#dc654e";
const green = "#51806b";
const blue = "#487cb4";
const yellow = "#f3ce55";

const ease = (frame: number, start: number, end: number) => {
  const value = interpolate(frame, [start, end], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
  return value * value * (3 - 2 * value);
};

type PanelCase = {kind: "elastic" | "inelastic" | "joined"; title: string; color: string; start: number; note: string};
type PanelPalette = {paper: string; ink: string; muted: string; rule: string; softRule: string; red: string; green: string; blue: string; yellow: string; mark: string};
const panelPalette = (dark: boolean): PanelPalette => dark ? {
  paper: "#080a09", ink: "#f1f4ef", muted: "#aab8ae", rule: "#405248", softRule: "#2b3a32",
  red: "#f08972", green: "#8dc6a4", blue: "#91b9eb", yellow: "#f6d56a", mark: "#675520",
} : {paper, ink, muted, rule, softRule: "#d8ddd7", red, green, blue, yellow, mark: yellow};
const panelCases: PanelCase[] = [
  {kind: "elastic", title: "ELÁSTICA", color: blue, start: 54, note: "Se separam"},
  {kind: "inelastic", title: "INELÁSTICA", color: red, start: 196, note: "Podem se separar"},
  {kind: "joined", title: "PERFEITAMENTE INELÁSTICA", color: green, start: 338, note: "Ficam unidos"},
];

const PanelBall: React.FC<{id: string; x: number; angle: number; color: "red" | "green"; palette: PanelPalette}> = ({id, x, angle, color, palette}) => {
  const isRed = color === "red";
  const light = isRed ? "#f9b39c" : "#a5cbb5";
  const base = isRed ? palette.red : palette.green;
  const dark = isRed ? "#a94638" : "#345b4b";
  return (
    <g transform={`translate(${x} 105)`}>
      <defs>
        <radialGradient id={`${id}-surface`} cx="28%" cy="24%" r="78%"><stop offset="0%" stopColor={light} /><stop offset="58%" stopColor={base} /><stop offset="100%" stopColor={dark} /></radialGradient>
        <clipPath id={`${id}-clip`}><circle r="29" /></clipPath>
      </defs>
      <ellipse cy="30" rx="28" ry="4" fill={palette.ink} opacity="0.13" />
      <circle r="29" fill={`url(#${id}-surface)`} />
      <g clipPath={`url(#${id}-clip)`} transform={`rotate(${angle})`}>
        <path d="M-35 -16 C-10 -28 8 -6 35 -17" fill="none" stroke={light} strokeWidth="6" opacity="0.75" />
        <path d="M-35 8 C-10 -6 10 22 36 9" fill="none" stroke={dark} strokeWidth="7" opacity="0.62" />
        <circle cx="14" cy="-15" r="5" fill={dark} opacity="0.7" />
      </g>
      <ellipse cx="-10" cy="-13" rx="9" ry="5" fill="white" opacity="0.2" />
      <circle r="29" fill="none" stroke={dark} strokeWidth="1.5" opacity="0.5" />
    </g>
  );
};

const PanelImpact: React.FC<{opacity: number; spread: number; palette: PanelPalette}> = ({opacity, spread, palette}) => (
  <g transform="translate(189 105)" opacity={opacity}>
    {Array.from({length: 8}, (_, index) => {
      const angle = (index * Math.PI) / 4;
      const near = 13 + spread * 5;
      const far = 24 + spread * 17;
      return <line key={index} x1={Math.cos(angle) * near} y1={Math.sin(angle) * near} x2={Math.cos(angle) * far} y2={Math.sin(angle) * far} stroke={palette.yellow} strokeWidth={index % 2 === 0 ? 3.5 : 2.5} strokeLinecap="round" />;
    })}
    <circle r={8 + 3 * spread} fill="#fff8db" stroke={palette.yellow} strokeWidth="2" />
  </g>
);

const CollisionPanel: React.FC<{item: PanelCase; index: number; frame: number; palette: PanelPalette}> = ({item, index, frame, palette}) => {
  const start = frame >= 525 ? 525 : item.start;
  const approach = ease(frame, start, start + 55);
  const after = ease(frame, start + 64, start + 118);
  const impact = ease(frame, start + 52, start + 59) * (1 - ease(frame, start + 69, start + 88));
  const x1 = 88 + 72 * approach + (item.kind === "elastic" ? -80 : item.kind === "inelastic" ? -34 : 62) * after;
  const x2 = 292 - 74 * approach + (item.kind === "elastic" ? 80 : item.kind === "inelastic" ? 34 : 62) * after;
  const focus = frame >= 500 || (frame >= item.start && frame < item.start + 140) ? 1 : 0.45;
  const appeared = ease(frame, 22 + index * 13, 52 + index * 13);
  const accent = [palette.blue, palette.red, palette.green][index];
  return (
    <div style={{width: "33.333%", height: 240, padding: "0 12px", boxSizing: "border-box", opacity: appeared * focus, borderLeft: index === 0 ? "none" : `1px solid ${palette.rule}`}}>
      <div style={{height: 45, display: "flex", alignItems: "center", gap: 11, borderTop: `4px solid ${accent}`, paddingTop: 5}}>
        <span style={{fontFamily: "Georgia, serif", fontSize: 24, color: accent}}>{`0${index + 1}`}</span>
        <span style={{fontSize: index === 2 ? 17 : 20, fontWeight: 700, whiteSpace: "nowrap"}}>{item.title}</span>
      </div>
      <svg width="100%" height="175" viewBox="0 0 380 175" role="img" aria-label={`Animação da colisão ${item.title.toLowerCase()}`}>
        <path d="M32 137 H348" stroke={palette.rule} strokeWidth="2" /><path d="M32 142 H348" stroke={palette.softRule} strokeWidth="1" />
        <path d="M104 44 H155 M150 39 L157 44 L150 49" fill="none" stroke={palette.red} strokeWidth="2.5" opacity={1 - approach} />
        <path d="M276 44 H225 M230 39 L223 44 L230 49" fill="none" stroke={palette.green} strokeWidth="2.5" opacity={1 - approach} />
        <PanelBall id={`${item.kind}-red`} x={x1} angle={((x1 - 88) / 29) * (180 / Math.PI)} color="red" palette={palette} />
        <PanelBall id={`${item.kind}-green`} x={x2} angle={((x2 - 292) / 29) * (180 / Math.PI)} color="green" palette={palette} />
        <PanelImpact opacity={impact} spread={ease(frame, start + 53, start + 80)} palette={palette} />
        <text x="190" y="166" textAnchor="middle" fill={palette.muted} fontSize="17" opacity={ease(frame, start + 68, start + 96)}>{item.note}</text>
      </svg>
    </div>
  );
};

const insights = [
  {at: 115, until: 248, color: blue, title: "ELÁSTICA", parts: ["p conservado", "K conservada", "e = 1"]},
  {at: 248, until: 390, color: red, title: "INELÁSTICA", parts: ["p conservado", "K diminui", "0 < e < 1"]},
  {at: 390, until: 510, color: green, title: "PERFEITAMENTE INELÁSTICA", parts: ["p conservado", "K diminui", "e = 0"]},
];

const panelRows = [
  {label: "Momento linear p", values: ["Conservado", "Conservado", "Conservado"]},
  {label: "Energia cinética K", values: ["Conservada", "Não conservada", "Não conservada"]},
  {label: "Depois da batida", values: ["Se separam", "Podem se separar", "Ficam unidos"]},
  {label: "Restituição e", values: ["e = 1", "0 < e < 1", "e = 0"]},
];

export const ThreePanelSummaryScene: React.FC<{dark?: boolean}> = ({dark = false}) => {
  const frame = useCurrentFrame();
  const title = ease(frame, 0, 32);
  const palette = panelPalette(dark);
  return (
    <AbsoluteFill style={{background: palette.paper, color: palette.ink, fontFamily: "'Segoe UI', sans-serif"}}>
      <div style={{position: "absolute", top: 45, left: 72, right: 72, opacity: title, transform: `translateY(${(1 - title) * 13}px)`}}>
        <h1 style={{fontSize: 48, lineHeight: 1.08, fontWeight: 600, margin: 0}}>Três formas de colisão.</h1>
        <div style={{fontSize: 20, color: palette.muted, marginTop: 8}}>O que permanece e o que muda depois do impacto?</div>
      </div>
      <div style={{position: "absolute", top: 173, left: 72, width: 1136, display: "flex", borderBottom: `1px solid ${palette.rule}`}}>
        {panelCases.map((item, index) => <CollisionPanel key={item.kind} item={item} index={index} frame={frame} palette={palette} />)}
      </div>
      {insights.map((insight, index) => {
        const opacity = ease(frame, insight.at, insight.at + 18) * (1 - ease(frame, insight.until - 18, insight.until));
        const accent = [palette.blue, palette.red, palette.green][index];
        return (
          <div key={insight.title} style={{position: "absolute", top: 452, left: 72, right: 72, opacity, transform: `translateY(${(1 - opacity) * 12}px)`}}>
            <div style={{fontSize: 15, fontWeight: 700, color: accent, marginBottom: 17}}>{insight.title}</div>
            <div style={{display: "flex", gap: 15}}>{insight.parts.map((part) => <div key={part} style={{borderTop: `4px solid ${accent}`, flex: 1, paddingTop: 13, fontSize: 28, fontWeight: 600}}>{part}</div>)}</div>
          </div>
        );
      })}
      <div style={{position: "absolute", top: 425, left: 72, right: 72, opacity: ease(frame, 485, 515)}}>
        <div style={{fontSize: 14, fontWeight: 700, color: palette.muted, marginBottom: 9}}>QUADRO COMPARATIVO</div>
        {panelRows.map((row, index) => {
          const reveal = ease(frame, 505 + index * 35, 530 + index * 35);
          return (
            <div key={row.label} style={{height: 40, display: "grid", gridTemplateColumns: "250px repeat(3, 1fr)", alignItems: "center", borderTop: `1px solid ${palette.rule}`, opacity: reveal, transform: `translateX(${(1 - reveal) * 14}px)`}}>
              <div style={{fontSize: 17, fontWeight: 600}}>{row.label}</div>
              {row.values.map((value, column) => <div key={column} style={{fontSize: 18, paddingLeft: 18, borderLeft: `1px solid ${palette.rule}`}}>{value}</div>)}
            </div>
          );
        })}
      </div>
      <div style={{position: "absolute", left: 72, right: 72, bottom: 38, borderTop: `2px solid ${palette.ink}`, paddingTop: 12, display: "flex", justifyContent: "space-between", alignItems: "center", opacity: ease(frame, 656, 688)}}>
        <span style={{fontSize: 15, fontWeight: 700, color: palette.muted}}>EM TODAS AS COLISÕES</span>
        <span style={{fontFamily: "Georgia, serif", fontSize: 30}}>p<sub>total</sub> = <span style={{background: palette.mark, padding: "0 6px 3px"}}>constante</span></span>
      </div>
    </AbsoluteFill>
  );
};
