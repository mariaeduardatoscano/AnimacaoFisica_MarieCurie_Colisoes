# Como a animacao foi feita

## 1. Situacao fisica

Duas bolinhas de massas iguais colidem. A primeira se move e a segunda esta inicialmente parada. Depois do impacto elas seguem juntas, caracterizando uma colisao perfeitamente inelastica.

- Massa da bolinha 1: `m1 = 0,2 kg`.
- Massa da bolinha 2: `m2 = 0,2 kg`.
- Velocidade inicial da bolinha 1: `v1i = 2,0 m/s`.
- Velocidade inicial da bolinha 2: `v2i = 0 m/s`.

Pela conservacao do momento linear:

```text
m1*v1i + m2*v2i = (m1 + m2)*vf
vf = (0,2*2,0 + 0,2*0) / (0,2 + 0,2)
vf = 1,0 m/s
```

A energia cinetica inicial e `Ki = (0,2*2,0^2)/2 = 0,4 J`. A energia final e `Kf = (0,4*1,0^2)/2 = 0,2 J`. Logo, `(1 - Kf/Ki)*100% = 50%` de perda de energia cinetica. O momento linear e conservado; parte da energia cinetica se transforma em outras formas de energia.

**Importante:** o valor usado no video e `2,0 m/s`, nao `20 m/s`. Com massas iguais e a segunda bolinha parada, `20 m/s` levaria a `vf = 10 m/s`; por isso `2,0 m/s` e necessario para o resultado exibido de `1,0 m/s`.

## 2. Estrutura visual

O componente `NumericalExampleScene` em `src/NumericalExample.tsx` monta tudo numa tela de 1280 x 720 pixels. Em cima aparecem, por etapas, a formula simbolica, a substituicao numerica, a velocidade final e a perda de energia. Na parte inferior, um diagrama SVG mostra as duas bolinhas se aproximando, o impacto e o movimento conjunto. As barras comparam `Ki = 100%` e `Kf = 50%`.

As bolinhas sao desenhadas com circulos SVG, gradiente radial e marcas curvas. As marcas giram junto com o deslocamento horizontal para transmitir a sensacao de rolamento. O efeito do impacto usa pequenos raios e particulas emitidos da regiao de contato. Nenhuma foto real e usada.

## 3. Animacao quadro a quadro

O Remotion chama o componente uma vez para cada quadro. `useCurrentFrame()` fornece o numero do quadro atual. A funcao `ease(frame, inicio, fim)` usa `interpolate` e uma curva suave para produzir um progresso entre 0 e 1. Assim, posicao, opacidade, rotacao e comprimento das barras dependem apenas do quadro, garantindo a mesma animacao no Studio e no MP4.

Pontos principais da linha do tempo (30 fps):

| Quadros aproximados | O que acontece |
| --- | --- |
| 0-48 | Entrada do titulo e das legendas do diagrama. |
| 52-168 | A bolinha vermelha se aproxima da verde. |
| 68-155 | Aparece a formula de conservacao do momento. |
| 145-285 | Divisorias e substituicao dos valores entram quando necessarias. |
| 165-201 | Ocorrem o contato, a pequena explosao visual e a uniao das bolinhas. |
| 186-375 | As duas bolinhas seguem juntas para a direita. |
| 265-348 | Surge o resultado `vf = 1,0 m/s`. |
| 305-440 | Barras de energia mostram 100% antes e 50% depois. |
| 365-445 | Aparece o calculo da perda de 50%. |
| 550-569 | Comeca o escurecimento final, interrompido pelo corte em 19 s. |

Os tempos sao determinados pelos quadros no arquivo `src/NumericalExample.tsx`, nao por `setTimeout` nem por reproducao de video externo.

## 4. Composicao e corte

`src/Root.tsx` registra somente `ExemploNumerico19s`, com `durationInFrames={570}` e `fps={30}`. Como `570/30 = 19`, o ultimo quadro e o 569. O componente original tinha uma duracao maior, mas a composicao encerra sua renderizacao no ponto solicitado. A cena de sintese nao e importada nem executada.

O script `scripts/render.cjs` empacota o codigo, procura a composicao e a renderiza em H.264. Antes de exportar, escolhe um nome livre para preservar MP4s anteriores. O `package-lock.json` fixa as versoes instaladas para facilitar a reproducao em outra maquina.
