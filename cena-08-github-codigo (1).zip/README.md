# Exemplo numerico de colisao (19 segundos)

Este repositorio contem **somente o codigo da animacao dos primeiros 19 segundos** do video `ExemploESintese.mp4`. A sintese comparativa e a cena 09 nao estao aqui. Todas as imagens sao geradas por React, CSS e SVG no Remotion; nao ha fotografias, videos externos nem audio.

## Reproduzir

Requisitos: Node.js, npm e Windows, macOS ou Linux. No terminal, dentro desta pasta:

```sh
npm ci
npm run dev
```

O Remotion Studio abre em `http://localhost:3003`. Selecione `ExemploNumerico19s` para assistir e examinar a linha do tempo.

Para verificar o codigo e gerar um MP4:

```sh
npm run lint
npm run render
```

O video fica em `out/ExemploNumerico-19s.mp4`. Renders posteriores recebem `-v02`, `-v03` etc., sem apagar os anteriores. `node_modules/` e `out/` estao no `.gitignore`; nao precisam ser enviados ao GitHub.

## O que cada arquivo faz

| Arquivo | Funcao |
| --- | --- |
| `src/index.ts` | Registra a raiz do projeto no Remotion. |
| `src/Root.tsx` | Define o video: 570 quadros, 30 fps, 1280 x 720 e fundo escuro. |
| `src/NumericalExample.tsx` | Desenha as formulas, as bolinhas, o impacto, as barras de energia e todas as animacoes. |
| `src/CollisionTheme.ts` | Centraliza as cores e o tema claro/escuro. |
| `scripts/render.cjs` | Exporta o MP4 H.264 sem substituir versoes anteriores. |
| `COMO_FOI_FEITO.md` | Explica os calculos fisicos e a construcao da animacao. |

## Por que sao exatamente 19 segundos?

O projeto original usa 30 quadros por segundo. Portanto, `19 x 30 = 570` quadros, numerados de 0 a 569. A parte da sintese do video combinado comeca apenas no quadro 576. Esta composicao termina antes disso e nao importa nenhum codigo da sintese.

O arquivo MP4 cortado anteriormente foi produzido do video combinado com FFmpeg, reencodificando para terminar exatamente em 19,0 s:

```sh
ffmpeg -i "ExemploESintese.mp4" -t 19 -c:v libx264 -preset medium -crf 18 -pix_fmt yuv420p -movflags +faststart "ExemploESintese-ate-19s.mp4"
```

Esse comando explica **o corte do MP4 original**. O codigo deste repositorio permite **renderizar os mesmos 570 quadros diretamente do Remotion**, sem precisar do video completo. Uma nova codificacao H.264 pode produzir bytes diferentes do MP4 cortado, mas a animacao e o intervalo de quadros sao os mesmos.
