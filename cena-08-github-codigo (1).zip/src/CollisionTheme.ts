import type {CSSProperties} from "react";

export const paper = "var(--collision-paper)";
export const ink = "var(--collision-ink)";
export const muted = "var(--collision-muted)";
export const rule = "var(--collision-rule)";
export const softRule = "var(--collision-soft-rule)";
export const energyTrack = "var(--collision-energy-track)";
export const mark = "var(--collision-mark)";
export const red = "var(--collision-red)";
export const green = "var(--collision-green)";
export const blue = "var(--collision-blue)";
export const yellow = "var(--collision-yellow)";

export const sceneTheme = (dark: boolean): CSSProperties => ({
  "--collision-paper": dark ? "#080a09" : "#f3f4f1",
  "--collision-ink": dark ? "#f1f4ef" : "#202723",
  "--collision-muted": dark ? "#aab8ae" : "#68736b",
  "--collision-rule": dark ? "#405248" : "#bec5bf",
  "--collision-soft-rule": dark ? "#2b3a32" : "#d8ddd7",
  "--collision-energy-track": dark ? "#2b3830" : "#dfe3dd",
  "--collision-mark": dark ? "#675520" : "#f3ce55",
  "--collision-red": dark ? "#f08972" : "#dc654e",
  "--collision-green": dark ? "#8dc6a4" : "#51806b",
  "--collision-blue": dark ? "#91b9eb" : "#487cb4",
  "--collision-yellow": dark ? "#f6d56a" : "#f3ce55",
} as CSSProperties);
