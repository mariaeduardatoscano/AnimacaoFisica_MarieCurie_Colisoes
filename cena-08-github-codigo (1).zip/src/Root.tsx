import React from "react";
import {Composition} from "remotion";
import {NumericalExampleScene} from "./NumericalExample";

export const Root: React.FC = () => (
  <Composition
    id="ExemploNumerico19s"
    component={NumericalExampleScene}
    defaultProps={{dark: true}}
    durationInFrames={570}
    fps={30}
    width={1280}
    height={720}
  />
);
