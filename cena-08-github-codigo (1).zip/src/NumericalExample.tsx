import React from "react";
import {AbsoluteFill, interpolate, useCurrentFrame} from "remotion";
import {blue, energyTrack, green, ink, mark, muted, paper, red, rule, sceneTheme, softRule, yellow} from "./CollisionTheme";

const ease = (frame: number, start: number, end: number) => {
  const value = interpolate(frame, [start, end], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
  return value * value * (3 - 2 * value);
};

const Reveal: React.FC<
  React.PropsWithChildren<{at: number; style?: React.CSSProperties}>
> = ({at, style, children}) => {
  const progress = ease(useCurrentFrame(), at, at + 22);
  return (
    <div
      style={{
        opacity: progress,
        transform: `translateY(${(1 - progress) * 14}px)`,
        ...style,
      }}
    >
      {children}
    </div>
  );
};

const Mark: React.FC<React.PropsWithChildren<{at: number}>> = ({at, children}) => {
  const progress = ease(useCurrentFrame(), at, at + 20);
  return (
    <span
      style={{
        background: `linear-gradient(90deg, ${mark} ${progress * 100}%, transparent ${progress * 100}%)`,
        padding: "1px 5px 3px",
        borderRadius: 2,
      }}
    >
      {children}
    </span>
  );
};

const Fraction: React.FC<{top: React.ReactNode; bottom: React.ReactNode}> = ({
  top,
  bottom,
}) => (
  <span
    style={{
      display: "inline-flex",
      flexDirection: "column",
      textAlign: "center",
      verticalAlign: "middle",
      lineHeight: 1.08,
    }}
  >
    <span style={{borderBottom: `2px solid ${ink}`, padding: "0 12px 6px"}}>
      {top}
    </span>
    <span style={{padding: "6px 12px 0"}}>{bottom}</span>
  </span>
);

const RollingBall: React.FC<{
  id: string;
  x: number;
  y: number;
  scale: number;
  rotation: number;
  light: string;
  base: string;
  dark: string;
}> = ({id, x, y, scale, rotation, light, base, dark}) => (
  <g transform={`translate(${x} ${y}) scale(${scale})`}>
    <defs>
      <radialGradient id={`${id}-surface`} cx="28%" cy="24%" r="78%">
        <stop offset="0%" stopColor={light} />
        <stop offset="57%" stopColor={base} />
        <stop offset="100%" stopColor={dark} />
      </radialGradient>
      <clipPath id={`${id}-clip`}>
        <circle r="29" />
      </clipPath>
    </defs>
    <ellipse cy="30" rx="25" ry="4" fill={ink} opacity="0.17" />
    <circle r="29" fill={`url(#${id}-surface)`} />
    <g clipPath={`url(#${id}-clip)`}>
      <g transform={`rotate(${rotation})`}>
        <path
          d="M-35 -19 C-14 -30 4 -7 35 -18"
          fill="none"
          stroke={light}
          strokeWidth="6"
          opacity="0.8"
        />
        <path
          d="M-34 3 C-7 -12 6 20 36 10"
          fill="none"
          stroke={dark}
          strokeWidth="7"
          opacity="0.68"
        />
        <path
          d="M-27 25 C-4 7 11 30 30 22"
          fill="none"
          stroke={light}
          strokeWidth="4"
          opacity="0.7"
        />
        <circle cx="13" cy="-13" r="5" fill={dark} opacity="0.72" />
        <circle cx="-16" cy="13" r="3" fill={light} opacity="0.85" />
      </g>
    </g>
    <ellipse cx="-10" cy="-13" rx="8" ry="5" fill="white" opacity="0.18" />
    <circle r="29" fill="none" stroke={dark} strokeWidth="1.5" opacity="0.55" />
  </g>
);

const CollisionDiagram = () => {
  const frame = useCurrentFrame();
  const approach = ease(frame, 52, 168);
  const travel = ease(frame, 186, 375);
  const x1 = 150 + 416 * approach + 320 * travel;
  const x2 = 640 + 320 * travel;
  const burst = ease(frame, 165, 171) * (1 - ease(frame, 179, 201));
  const burstSpread = ease(frame, 165, 192);
  const joined = ease(frame, 174, 198);
  const beforeLabelOpacity = 1 - ease(frame, 158, 174);
  const labelOpacity = ease(frame, 28, 48);
  const ballScale = 1.3;
  const ballRadius = 29 * ballScale;
  const roll1 = ((x1 - 150) / ballRadius) * (180 / Math.PI) * 1.4;
  const roll2 = ((x2 - 640) / ballRadius) * (180 / Math.PI) * 1.4;

  return (
    <svg width="1136" height="215" viewBox="0 0 1136 215">
      <text x="20" y="24" fill={muted} fontSize="16" fontWeight="600">
        ANTES DA BATIDA
      </text>
      <text
        x="1000"
        y="24"
        fill={green}
        fontSize="16"
        fontWeight="600"
        opacity={joined}
      >
        DEPOIS
      </text>
      <line x1="20" y1="168" x2="1116" y2="168" stroke={rule} strokeWidth="2" />
      <line x1="20" y1="173" x2="1116" y2="173" stroke={softRule} />
      <path
        d={`M${x1 - 145} 77 H${x1 - 52}`}
        stroke={red}
        strokeWidth="4"
        strokeLinecap="round"
        opacity={labelOpacity * (1 - joined)}
      />
      <path
        d={`M${x1 - 63} 70 L${x1 - 49} 77 L${x1 - 63} 84`}
        fill="none"
        stroke={red}
        strokeWidth="4"
        strokeLinecap="round"
        strokeLinejoin="round"
        opacity={labelOpacity * (1 - joined)}
      />
      <text
        x={x1 - 145}
        y="57"
        fill={red}
        fontSize="20"
        fontWeight="600"
        opacity={labelOpacity * (1 - joined)}
      >
        2,0 m/s
      </text>
      <RollingBall id="mass-one" x={x1} y={130} scale={ballScale} rotation={roll1} light="#f9b39c" base={red} dark="#a94638" />
      <RollingBall id="mass-two" x={x2} y={130} scale={ballScale} rotation={roll2} light="#a5cbb5" base={green} dark="#345b4b" />
      <g transform="translate(603 130)" opacity={burst}>
        {Array.from({length: 9}, (_, i) => {
          const angle = ((i * 40 - 160) * Math.PI) / 180;
          const inner = 9 + 8 * burstSpread;
          const outer = 23 + 25 * burstSpread;
          return (
            <g key={i}>
              <line
                x1={Math.cos(angle) * inner}
                y1={Math.sin(angle) * inner}
                x2={Math.cos(angle) * outer}
                y2={Math.sin(angle) * outer}
                stroke={i % 2 === 0 ? yellow : "#f9e7a3"}
                strokeWidth={i % 3 === 0 ? 4 : 3}
                strokeLinecap="round"
              />
              {i % 2 === 0 && (
                <circle
                  cx={Math.cos(angle) * (outer + 7)}
                  cy={Math.sin(angle) * (outer + 7)}
                  r="2.5"
                  fill={yellow}
                />
              )}
            </g>
          );
        })}
        <circle r={8 + 3 * burstSpread} fill="#fff8db" stroke={yellow} strokeWidth="3" />
      </g>
      <text x={x1} y="198" textAnchor="middle" fill={muted} fontSize="18" opacity={beforeLabelOpacity}>
        m₁
      </text>
      <text x={x2} y="198" textAnchor="middle" fill={muted} fontSize="18" opacity={beforeLabelOpacity}>
        m₂
      </text>
      <text x="395" y="204" textAnchor="middle" fill={muted} fontSize="16" opacity={beforeLabelOpacity}>
        0,2 kg cada
      </text>
      <text x={(x1 + x2) / 2} y="198" textAnchor="middle" fill={muted} fontSize="18" opacity={joined}>
        m₁ + m₂ = 0,4 kg
      </text>
      <path
        d={`M${x2 + 56} 77 H${x2 + 120} M${x2 + 107} 70 L${x2 + 121} 77 L${x2 + 107} 84`}
        stroke={green}
        strokeWidth="4"
        fill="none"
        strokeLinecap="round"
        strokeLinejoin="round"
        opacity={joined}
      />
      <text x={x2 + 54} y="57" fill={green} fontSize="20" fontWeight="600" opacity={joined}>
        1,0 m/s
      </text>
    </svg>
  );
};

const EnergyBars = () => {
  const frame = useCurrentFrame();
  const initial = ease(frame, 305, 370);
  const final = ease(frame, 370, 440);
  return (
    <svg width="500" height="94" viewBox="0 0 500 94">
      <text x="0" y="27" fontSize="17" fill={ink} fontWeight="600">
        Energia cinética
      </text>
      <text x="0" y="59" fontSize="16" fill={muted}>
        Kᵢ
      </text>
      <text x="0" y="86" fontSize="16" fill={muted}>
        Kf
      </text>
      <rect x="44" y="43" width="285" height="18" fill={energyTrack} />
      <rect x="44" y="43" width={285 * initial} height="18" fill={blue} />
      <rect x="44" y="70" width={142.5 * final} height="18" fill={green} />
      <text x="344" y="59" fontSize="17" fill={ink} opacity={initial}>
        100%
      </text>
      <text x="202" y="86" fontSize="17" fill={green} fontWeight="600" opacity={final}>
        50%
      </text>
    </svg>
  );
};

export const NumericalExampleScene: React.FC<{dark?: boolean}> = ({dark = false}) => {
  const frame = useCurrentFrame();
  const fadeOut = ease(frame, 550, 599);
  const firstSeparator = ease(frame, 145, 175);
  const secondSeparator = ease(frame, 255, 285);

  return (
    <AbsoluteFill
      style={{
        background: paper,
        color: ink,
        fontFamily: "'Segoe UI', sans-serif",
        opacity: ease(frame, 0, 22),
        ...sceneTheme(dark),
      }}
    >
      <Reveal at={6} style={{position: "absolute", top: 47, left: 72, right: 72}}>
        <h1 style={{fontSize: 50, fontWeight: 600, lineHeight: 1.1, margin: 0}}>
          Vamos calcular a colisão.
        </h1>
        <div style={{fontSize: 21, color: muted, marginTop: 8}}>
          Massas iguais, corpos unidos após o impacto.
        </div>
      </Reveal>

      <div style={{position: "absolute", left: 424, top: 184, height: 132, width: 1, background: rule, opacity: firstSeparator, transform: `scaleY(${firstSeparator})`, transformOrigin: "top"}} />
      <div style={{position: "absolute", left: 826, top: 184, height: 132, width: 1, background: rule, opacity: secondSeparator, transform: `scaleY(${secondSeparator})`, transformOrigin: "top"}} />

      <Reveal at={68} style={{position: "absolute", left: 72, top: 187, width: 330}}>
        <div style={{fontSize: 16, color: muted, marginBottom: 16}}>CONSERVAÇÃO DO MOMENTO</div>
        <div style={{fontFamily: "Georgia, serif", fontSize: 30}}>
          v<sub>f</sub> = <Fraction top={<>m<sub>1</sub>v<sub>1i</sub></>} bottom={<>m<sub>1</sub> + m<sub>2</sub></>} />
        </div>
      </Reveal>

      <Reveal at={155} style={{position: "absolute", left: 451, top: 187, width: 350}}>
        <div style={{fontSize: 16, color: muted, marginBottom: 16}}>SUBSTITUINDO OS VALORES</div>
        <div style={{fontFamily: "Georgia, serif", fontSize: 27}}>
          v<sub>f</sub> = <Fraction top={<Mark at={180}>0,2 × 2,0</Mark>} bottom={<Mark at={210}>0,2 + 0,2</Mark>} />
        </div>
      </Reveal>

      <Reveal at={265} style={{position: "absolute", left: 855, top: 187, width: 350}}>
        <div style={{fontSize: 16, color: muted, marginBottom: 16}}>VELOCIDADE FINAL</div>
        <div style={{fontFamily: "Georgia, serif", fontSize: 38}}>
          v<sub>f</sub> = <Mark at={295}>1,0 m/s</Mark>
        </div>
        <svg width="300" height="20" viewBox="0 0 300 20" style={{display: "block", marginTop: 8}}>
          <path
            d="M65 11 Q158 18 264 9"
            stroke={green}
            strokeWidth="3"
            fill="none"
            pathLength={1}
            strokeDasharray={1}
            strokeDashoffset={1 - ease(frame, 315, 348)}
          />
        </svg>
      </Reveal>

      <Reveal at={365} style={{position: "absolute", left: 72, top: 351, width: 550}}>
        <div style={{fontSize: 16, color: muted, marginBottom: 13}}>PERDA DE ENERGIA</div>
        <div style={{fontFamily: "Georgia, serif", fontSize: 29, whiteSpace: "nowrap"}}>
          (1 − K<sub>f</sub>/K<sub>i</sub>) × 100% = <Mark at={425}>50%</Mark>
        </div>
      </Reveal>
      <Reveal at={310} style={{position: "absolute", left: 707, top: 327}}>
        <EnergyBars />
      </Reveal>

      <div style={{position: "absolute", top: 455, left: 72, right: 72, height: 1, background: rule}} />
      <Reveal at={20} style={{position: "absolute", left: 72, top: 475, width: 1136}}>
        <CollisionDiagram />
      </Reveal>
      <AbsoluteFill style={{background: "#111613", opacity: fadeOut}} />
    </AbsoluteFill>
  );
};
